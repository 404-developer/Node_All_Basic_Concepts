const { check, body, validationResult } = require('express-validator')

exports.nameValidation =
    [
        check("name")
            .trim()
            .not()
            .isEmpty()
            .withMessage("Name is required")
            .isLength({ min: 3, max: 15 })
            .withMessage("Name must be min 3 and max 15 characters")
    ]


exports.emailValidation =
    [
        check("email")
            .trim()
            .not()
            .isEmpty()
            .withMessage("Email is required")
            .isEmail()
            .normalizeEmail()
            .withMessage("Invalid email address")
    ]


exports.passwordValidation =
    [
        check("password")
            .trim()
            .not()
            .isEmpty()
            .withMessage("Password is required")
            .isLength({ min: 6, max: 15 })
            .withMessage("Password must be Min 6 and Max 15 characters")
            .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.+[0-9][0-9])(?=.*[!@#\$%\^&\*])(?=.{6,10})/)
            .withMessage("Password must min 6 char max 10 char one caps one symbol and 2 number")
    ]


exports.phoneValidation =
    [
        check("phone")
            .trim()
            .not()
            .isEmpty()
            .withMessage("Phone number is required")
            .isNumeric()
            .withMessage('Numeric only')
            .isLength({ min: 10 })
            .withMessage("Phone number Min 10")
    ]

exports.countryValidation =
    [
        check("country")
            .trim()
            .not()
            .isEmpty()
            .withMessage("Country is required")
            .isLength({ min: 3, max: 15 })
            .withMessage("Country must be min 3 and max 15 characters")
    ]


exports.cityValidation =
    [
        check("city")
            .trim()
            .not()
            .isEmpty()
            .withMessage("City is required")
            .isLength({ min: 3, max: 15 })
            .withMessage("City must be min 3 and max 15 characters")
    ]


exports.roleValidation =
    [
        check("role")
            .trim()
            .not()
            .isEmpty()
            .withMessage("Role is required")
            .isLength({ min: 3, max: 15 })
            .withMessage("Role must be min 3 and max 15 characters")
    ]


exports.ageValidation =
    [
        check("age")
            .trim()
            .not()
            .isEmpty()
            .withMessage("Age is required")
            .isNumeric()
            .withMessage('Numeric only')
    ]

exports.pincodeValidation =
    [
        check("pincode")
            .trim()
            .not()
            .isEmpty()
            .withMessage("Pincode is required")
            .isNumeric()
            .withMessage('Numeric only')
            .isLength({ min: 6 })
            .withMessage("6 Digits only")
    ]



exports.validationError = (req, res, next) => {
    const result = validationResult(req).array();
    if (!result.length) return next();
    const error = result[0].msg;
    res.status(406).json({ status: false, message: error });
}
