const express = require('express')
const app = express()
app.use(express.json())
const dotenv = require('dotenv')
dotenv.config()

const employeeRouter = require('./routes/employeeRouter')
const adminRouter = require('./routes/adminRouter')

app.use('/employee', employeeRouter)
app.use('/admin', adminRouter)


module.exports = app