const adminSchema = require('../model/admin')
const employeeSchema = require('../model/employee')
const Cryptr = require("cryptr")
const cryptr = new Cryptr("my_Admin_Secret_Key")
const jwt = require('jsonwebtoken')


const jwtKey = "my_admin_secret_key"
const jwtExpirySeconds = 300


exports.adminRegister = (req, res) => {

    const { name, email, password, confirmpassword } = req.body

    let adminRegister = new adminSchema({
        name: name,
        email: email,
        password: cryptr.encrypt(password),
        confirmpassword: cryptr.encrypt(confirmpassword),
        createdAt: new Date()
    })

    adminSchema.findOne({ email: email })
        .then((data) => {
            if (data) {
                res.status(400).json({ message: "Email already taken" })
            }

            else if (password == confirmpassword) {
                adminRegister.save((err, data) => {
                    if (err) {
                        res.status(400).json({ status:false, message: "Registration failed" })
                    }
                    else {
                        res.status(201).json({ status:true, message: "Register successfully", data: data })
                    }
                })
            }
            else {
                res.status(400).json({ status:false, message: "Password and Confirmpassword can't match" })
            }

        })

}


exports.adminLogin = (req, res) => {

    const { email, password } = req.body

    adminSchema.findOne({ email: email }, (err, data) => {
        if (data) {
            if (cryptr.decrypt(data.password) == password) {

                const email = data.email

                const token = jwt.sign({ email }, jwtKey, {
                    algorithm: "HS256",
                    expiresIn: jwtExpirySeconds,
                })

                res.status(200).json({ status:true, message: "Login success", token: token })

            }
            else {
                res.status(401).json({ status:false, message: "Login failed" })
            }
        }
        else
        {
            res.status(401).json({ status:false, message: "Invalid Email or Password" })
        }
    })

}


exports.adminVerify = (req, res) => {

    try {
        var adminPayload = jwt.verify(req.token, jwtKey)

        employeeSchema.find({})
            .then((data) => {
                res.status(200).json({
                    status:true,
                    success: "verified successfully",
                    message: `Welcome ${adminPayload.email}!`,
                    employee_data: data
                })
            })
    }
    catch (err) {
        res.status(401).json({
            status:false,
            message: "invalid Jwt Token"
        })
    }
}

