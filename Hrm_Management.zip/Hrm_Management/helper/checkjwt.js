exports.checkToken = (req, res, next) => {
    const tokenHeader = req.headers['authorization'];
    if (typeof tokenHeader !== 'undefined') {
        const token = tokenHeader.split(" ");
        const tokens = token[1];
        req.token = tokens
        next()
    }
    else {
        res.status(403).json({ status: false, message: "JWT can't be null" })
    }
}