const employeeSchema = require('../model/employee')
const employeeHistorySchema = require('../model/employeloginhistory')
const Cryptr = require("cryptr")
const cryptr = new Cryptr("my_Employee_Secret_Key")
const os = require('os')
const jwt = require('jsonwebtoken')
const ip = require('ip')
const moment = require('moment')
const cloudinary = require('../utills/cloudinary')

const jwtKey = "my_employee_secret_key"
const jwtExpirySeconds = 300



exports.employeeRegister = (req, res) => {

    var employeeId = Math.floor(1000 + Math.random() * 9000)

    const { name, email, password, confirmpassword } = req.body

    let employeeRegister = new employeeSchema({
        employeeid: 'EMP' + employeeId,
        name: name,
        email: email,
        password: cryptr.encrypt(password),
        confirmpassword: cryptr.encrypt(confirmpassword),
        createdAt: new Date()
    })

    employeeSchema.findOne({ email: email })
        .then((data) => {
            if (data) {
                res.status(400).json({ status: false, message: "Email already taken" })
            }
            else if (password == confirmpassword) {
                employeeRegister.save((err, data) => {
                    if (err) {
                        res.status(400).json({ status: false, message: "Registration failed" })
                    }
                    else {
                        res.status(201).json({ status: true, message: "Register successfully", data: data })
                    }
                })
            }
            else {
                res.status(400).json({ status: false, message: "Password and Confirmpassword can't match" })
            }

        })

}

var userCount = 0

exports.employeeLogin = (req, res) => {

    var today = new Date();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    // var dateTime = date + ' ' + time;

    const { email, password } = req.body

    userCount++

    employeeSchema.findOneAndUpdate({ email: email }, { $set: { logintime: time, logincount: userCount, loginip: ip.address() } }, function (err, data) {

        if (data) {
            let history = new employeeHistorySchema({
                name: data.name,
                email: data.email,
                logintime: time,
                role: data.role,
                loginip: ip.address(),
                os: os.platform() + ' ' + os.arch()
            })

            history.save()

            if (cryptr.decrypt(data.password) == password) {

                const email = data.email

                const token = jwt.sign({ email }, jwtKey, {
                    algorithm: "HS256",
                    expiresIn: jwtExpirySeconds,
                })

                res.status(200).json({ status: true, message: "Login success", token: token })

            }
            else {
                res.status(401).json({ status: false, message: "Login failed" })
            }
        }
        else {
            res.status(401).json({ status: false, message: "Invalid email or password" })
        }
    })

}



exports.employeeVerify = (req, res) => {

    try {
        var employeePayload = jwt.verify(req.token, jwtKey)
        employeeHistorySchema.find({ email: employeePayload.email })
            .then((data) => {
                res.json({
                    status: true,
                    success: "verified successfully",
                    msg: `Welcome ${employeePayload.email}!`,
                    login_history: data
                })
            })
    }
    catch (err) {
        res.json({
            status: false,
            msg: "Invalid Jwt Token"
        })
    }
}


exports.employeeLogout = (req, res) => {

    var today = new Date()
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds()

    employeeSchema.findOneAndUpdate({ email: req.body.email }, { $set: { logouttime: time, } }, function (err, data) {

        if (data) {
            const startTime = moment(data.logintime, "HH:mm:ss")
            const endTime = moment(data.logouttime, "HH:mm:ss")
            const duration = moment.duration(endTime.diff(startTime))
            const hours = parseInt(duration.asHours())
            const minutes = parseInt(duration.asMinutes()) % 60
            const seconds = parseInt(duration.seconds())

            var totalWorkedHour = hours + ':' + minutes + ':' + seconds

            const startTime1 = moment(totalWorkedHour, "HH:mm:ss")
            const endTime1 = moment("08:20:00", "HH:mm:ss")
            const duration1 = moment.duration(endTime1.diff(startTime1))
            const hours1 = parseInt(duration1.asHours())
            const minutes1 = parseInt(duration1.asMinutes()) % 60
            const seconds1 = parseInt(duration1.seconds())

            res.json({ "login_time": data.logintime, "logout_time": data.logouttime, "total_worked_time": hours + ' Hours ' + minutes + ' Minutes ' + seconds + ' Seconds', "remaining_work_time": hours1 + ' Hours ' + minutes1 + ' Minutes ' + seconds1 + ' Seconds' })
        }
        else {
            res.status(400).json({ status: false, message: "Invalid Email" })
        }
    })

}



exports.updateProfile = (req, res) => {

    const { email, age, phone, country, city, role, pincode } = req.body

    employeeSchema.findById({ _id: req.params._id }, function (err, data) {
        employeeSchema.updateOne({ _id: data._id }, { $set: { email: email, age: age, phone: phone, country: country, city: city, role: role, pincode: pincode, modifiedAt: new Date() } }, (err, data) => {
            if (err) {
                res.status(401).json({ status: false, message: "Failed to update your profile" })
            }
            else {
                res.status(200).json({
                    status: true,
                    message: "Profile updated successfully", data: data
                })
            }
        })
    })

}

exports.imageUpload = async (req, res) => {

    let imageData = await cloudinary.uploader.upload(req.file.path)

    employeeSchema.findOneAndUpdate({ _id: req.params._id }, { $set: { profile: imageData.secure_url } }, function (err, data) {

        if (data) {
            res.status(200).json({ status: true, message: data })
        }
        else {
            res.status(401).json({ status: false, message: "Failed to upload" })
        }

    })

}

