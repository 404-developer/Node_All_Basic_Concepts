const mongoose = require('mongoose')

mongoose.connect(process.env.DB_URL), (err,res) =>
{
    if(err)
    {
        console.log("DB connection failed")
    }
    else
    {
        console.log("Db connected succesfully")
    }
}

module.exports = mongoose