const employeeSchema = require('../config/config')

const employee = new employeeSchema.Schema(
    {
        empid:{
            type:String
        },
        name:
        {
            type: String
        },
        email:
        {
            type: String
        },
        password:
        {
            type: String
        },
        confirmpassword:
        {
            type: String
        },
        age:
        {
            type: Number
        },
        phone:
        {
            type: Number
        },
        country:
        {
            type: String
        },
        city:
        {
            type: String
        },
        pincode:
        {
            type: Number,
        },
        role:
        {
            type:String
        },
        profile:
        {
            type:String
        },
        createdAt:
        {
            type: String
        },
        modifiedAt:
        {
            type: String
        },
        logintime:
        {
            type:String
        },
        logouttime:
        {
            type:String
        },
        logincount:
        {
            type: Number
        },
        loginip:
        {
            type:String
        }
    }
)


module.exports = employeeSchema.model('employee', employee)