const adminSchema = require('../config/config')

const admin = new adminSchema.Schema(
    {
        name:
        {
            type: String
        },
        email:
        {
            type: String
        },
        password:
        {
            type: String
        },
        confirmpassword:
        {
            type: String
        }
    }
)


module.exports = adminSchema.model('admin', admin)