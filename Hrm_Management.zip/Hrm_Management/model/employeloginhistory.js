const employeeLoginHistorySchema = require('../config/config')

const loginHistory = new employeeLoginHistorySchema.Schema(
    {
        name:
        {
            type: String
        },
        email:
        {
            type: String
        },
        logintime:
        {
            type: String
        },
        role:
        {
            type: String
        },
        loginip:
        {
            type: String
        },
        os:
        {
            type:String
        }
    }
)


module.exports = employeeLoginHistorySchema.model('loginHistory', loginHistory)