const express = require('express')
const router = express.Router()
const employee = require('../helper/employee')
const { nameValidation, emailValidation, passwordValidation, validationError, phoneValidation, ageValidation, pincodeValidation, countryValidation, cityValidation, roleValidation } = require('../middleware/validation')
const { checkToken } = require('../helper/checkjwt')
const multer = require('../utills/multer')

router.post('/employee_register', nameValidation, emailValidation, passwordValidation, validationError, employee.employeeRegister)
router.put('/update_employee_profile/:_id', nameValidation, emailValidation, phoneValidation, countryValidation, cityValidation, roleValidation, ageValidation, pincodeValidation, validationError, employee.updateProfile)
router.post('/employee_login', employee.employeeLogin)
router.post('/employee_verify', checkToken, employee.employeeVerify)
router.post('/employee_logout', employee.employeeLogout)
router.post('/upload/:_id', multer.single('images'),employee.imageUpload)


module.exports = router