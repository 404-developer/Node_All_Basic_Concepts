const express = require('express')
const router = express.Router()
const admin = require('../helper/admin')
const { nameValidation, emailValidation, passwordValidation, validationError } = require('../middleware/validation')
const { checkToken } = require('../helper/checkjwt')


router.post('/admin_register', nameValidation, emailValidation, passwordValidation, validationError, admin.adminRegister)
router.post('/admin_login', admin.adminLogin)
router.post('/admin_verify', checkToken, admin.adminVerify)


module.exports = router